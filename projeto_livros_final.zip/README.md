# Projeto Livros - CRUD, Backup, Análise e Machine Learning
Sistema completo em Flask com:
- CRUD de livros (CSV como banco)
- Backup automático
- Análises com gráficos
- Treino de modelos ML
- Predição
- venv recomendado
